<?php require("conexao.php"); ?>
<?php
$query_rs_edi = "SELECT * FROM tb_produts WHERE tb_produts.ativo = 1 and tb_produts.id_Area = 1 OR tb_produts.id_Area = 2 ORDER BY tb_produts.id_Produts DESC";
$rs_edi = mysqli_query($conn_bd_edibolos, $query_rs_edi) or die(mysqli_error($conn_bd_edibolos));
$totalRow_rs_edi = mysqli_num_rows($rs_edi);
$row_rs_edi = mysqli_fetch_assoc($rs_edi);

?>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Pagina de Bolos Edi Bolos.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="language" content="pt-BR">
    <link href="bootstrap441/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="bootstrap441/js/bootstrap.min.js" rel="stylesheet" type="text/js">
    <link rel="stylesheet" href="style_bolos.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="">
    <link rel="shortcut icon" href="imgs/favicon_84x87.png" type="image/x-icon"> 
    <title>Página Bolos</title>
    <script type="text/javascript">(function () {var options = {whatsapp: "+5511984455345",company_logo_url: "", greeting_message: "Olá!", call_to_action: "Entre em contato conosco!", position: "right", };var proto = document.location.protocol, host = "jivo.link", url = proto + "//" + host;var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/ferramentas-de-marketing/jivowpp.js';s.onload = function () { WhWidgetSendButton.init(host, proto, options); };var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);})();</script>

</head>

<body>
  <h2 class="fonte-zero">Página html</h2>

<!-----------------------------||INÍCIO DO HEADER||----------------------------------->     
<header> 

<!--Topo--> 
<?php include("_topo.php");?>


<!--Navbar--> 
<?php include("_navbar.php");?>

</header>
<!-----------------------------||FIM HEADER||-----------------------------------> 
<main style="background-color: #ffe6d1;"  >

  <div class="alert alert-dark text-center texto-logo shadow-lg p-3 mb-1 rounded" style="background-color: #51B07C;">
  Todos os Bolos:
<?php echo($totalRow_rs_edi); ?>
  </div>

  <?php include("_cards.php");?>


<!----OBS: o Rodape está dentro do main-----------------------> 

<!--Rodape Inicio-->    
<?php include("_rodape.php");?>
<!--Rodape Fim-->


</main>
</section>
<!-----------------------------||FIM DO MAIN||----------------------------------->     

<!--links JS-->
<?php include("_complementos.php");?>
  
<script src="js/animation_home.js" ></script>

</section>
</body>
</html>
