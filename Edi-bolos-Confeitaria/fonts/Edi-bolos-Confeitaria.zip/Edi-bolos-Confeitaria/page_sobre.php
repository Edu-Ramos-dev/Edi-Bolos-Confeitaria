<!DOCTYPE html>
<html lang="pt-BR">
    
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Edi Bolos Contato.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="language" content="pt-BR">
    <link href="bootstrap441/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="bootstrap441/js/bootstrap.min.js" rel="stylesheet" type="text/js">
    <link rel="stylesheet" href="style_sobre.css"> 
    <link rel="shortcut icon" href="imgs/favicon_84x87.png" type="image/x-icon">
    <title>Edi Bolos</title>
    <script type="text/javascript">(function () {var options = {whatsapp: "+5511984455345",company_logo_url: "", greeting_message: "Olá!", call_to_action: "Entre em contato conosco!", position: "right", };var proto = document.location.protocol, host = "jivo.link", url = proto + "//" + host;var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/ferramentas-de-marketing/jivowpp.js';s.onload = function () { WhWidgetSendButton.init(host, proto, options); };var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);})();</script>

</head>

<body>
  <h2 class="fonte-zero">Página html</h2>

<!-----------------------------||INÍCIO DO HEADER||----------------------------------->     
<header> 

<!--Topo--> 
<?php include("_topo.php");?>


<!--Navbar--> 
<?php include("_navbar.php");?>

</header>
<!-----------------------------||FIM HEADER||-----------------------------------> 

   
 <!--INICIO MAIN-->
<main style="background-color: #ffe6d1;">
  <div class="alert alert-dark text-center texto-logo shadow-lg p-3 mb-4 rounded" style="background-color: #51B07C;">
  Sobre
  </div>

  <div class="container-fluid mb-3">
    <div class="row">
        <div class="col-lg-6" style="justify-content: left;" >
            <div>
                <img src="imgs/fotoPerfil.jpg" class="img-fluid" id="fotoperft" alt="..." style="width: 100%;">
            </div>
        </div>
    
        <div class="col-lg-6">
           <div>
            <p class="font-ti-bolo ml-3 mt-4 font-ti-bolo ">Quem é Edi Bolos?</p>
          </div>

           <div>
          <p class="font-te-bolo">

          <br>Me chamo Edinalva Teodoro, tenho 46 anos, sou mãe, esposa e apaixonado pela confeitaria.
          <br>

          <br>sempre gostei de cozinhar e fazia bolos para os aniversários da minha familia, mas descobri minha paixão pelos doces, principalmente por bolos em 2017 aonde iniciei meu empreeendimento "Edi Bolos"<br>
          <br>

          Amo meu trabalho e faço com o maior carinho  para que cada cliente sinta-se especial e possa compartilhar com as pessoas que ama a vida um pouco mais doce.</p>
            </div>
        </div>
    </div>
</div>

<!--Rodape Inicio-->    
<?php include("_rodape.php");?>
<!--Rodape Fim-->


</main>
</section>
<!-----------------------------||FIM DO MAIN||----------------------------------->     

<!--links JS-->
<?php include("_complementos.php");?>
    
<script src="js/animation_home.js" ></script>

</section>
</body>
</html>