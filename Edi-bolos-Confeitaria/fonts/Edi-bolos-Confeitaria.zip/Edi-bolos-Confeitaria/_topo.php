<!--INICIO TOPO-->
<div class="container-fluid c-cont-header"> 
  <div class="container">
    <div class="row">
        
     <div class="text-center mt-4 mb-4 col-xl-12">

       <section> <!--Inicio da seção com o Logo da Edi Bolos com link para a página index.php-->
         <h2 class="fonte-zero">Logo Edi Bolos</h2>
         <a href="index.php" title="Logo Edi Bolos confeitaria"> <!--Link para página index.php-->
         <img id="imgLogo" class="img-fluid" src="imgs/logo-370x97.png" alt="logo Edi Bolos" title="logo Edi Bolos">
        
         </a>
       </section> 
       <div class="text-center texto-logo col-xl-12"> <!--Início da seção com o slogan da empresa-->
         <section>
          <h2 class="fonte-zero">Slogan</h2>
              Experimente e Apaixone-se
        </section><!--Fim da Seção-->
       </div>

       </div>
    </div>
  </div>
 </div>
 <!-- FIM TOPO-->
